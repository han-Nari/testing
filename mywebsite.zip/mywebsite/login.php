<?php 
	require_once "session.php";
	$dsn = "mysql:host=localhost;dbname=login";
	$dbusername = 'root';
	$dbpass = '';

	try {
		// DSN
		$pdo = new PDO($dsn, $dbusername, $dbpass);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

		// if($pdo) {
		// 	echo "connected";
		// }

	} catch(PDOException $e) {
		die("Connection failed" . $e->getMessage());
	}

	if(isset($_POST["submit"])) {
		$email = $_POST["email"];
		$pwd = $_POST["password"];

		$query = "SELECT * FROM login WHERE email = :email";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(":email", $email);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		 if(!$result) {
             echo "email not found";
          } else {
          	$_SESSION["email"] = $email;
          	header("location: welcome.php");
          }

	}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="register.css">
</head>
<body>
<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
	<div class="box">
		<input type="text" name="email" placeholder="Email">
	</div>
	<div class="box">
		<input type="password" name="password" id="show" placeholder="Password">
	</div>
	<input class="btn" type="submit" name="submit" value="Login">
</form>
</body>
</html>